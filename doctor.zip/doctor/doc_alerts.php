<?php
require_once '../config/db.php'; // Database connection

// Fetch all critical appointments
$stmt = $pdo->prepare("SELECT a.id, a.patient_id, u.name AS patient_name, a.appt_date, a.appt_time, a.appt_type, a.notes
                       FROM appointments a
                       JOIN users u ON a.patient_id = u.id
                       WHERE a.status = 'Critical'
                       ORDER BY a.appt_date ASC, a.appt_time ASC");
$stmt->execute();
$critical_appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Critical Alerts</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --pink-100: #fde6eb;
    --pink-200: #f8d7de;
    --pink-300: #f6c6cd;
    --accent: #ec8fa0;
    --muted: #9b9b9b;
    --text-color: #3f3f3f;
    --background-color: #ffffff;
    --card-shadow: 0 6px 20px rgba(236,80,120,0.1);
    --transition: all 0.3s ease;
    font-family: 'Inter', Arial, sans-serif;
}
body { margin:0; background: var(--background-color); color: var(--text-color); }
.navbar { background: var(--pink-300); padding: 6px 18px; display:flex; align-items:center; justify-content:space-between; height:60px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);}
.navbar a { color: var(--text-color); text-decoration:none; font-size:20px; }
.navbar i { font-size:22px; cursor:pointer; }
.container { max-width:1200px; margin:auto; padding:20px; }
h1 { color: var(--accent); margin-bottom: 20px; }
.card { background: var(--pink-100); padding: 16px; border-radius:12px; box-shadow: var(--card-shadow); margin-bottom: 16px; transition: var(--transition); }
.card:hover { transform: translateY(-2px); }
.card-header { display:flex; justify-content: space-between; align-items:center; margin-bottom:8px; }
.patient-name { font-weight:700; font-size:18px; color: var(--accent); }
.status { font-weight:700; color: #ff4d4f; }
.details { font-size:14px; color: var(--text-color); margin-top:4px; }
</style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <a href="doc_dashboard.php"><i class="fa-solid fa-house"></i></a>
    <div>Critical Alerts</div>
    <a href="doc_logout.php"><i class="fa-solid fa-right-from-bracket"></i></a>
</div>

<div class="container">
    <h1>Critical Alerts</h1>

    <?php if(count($critical_appointments) > 0): ?>
        <?php foreach($critical_appointments as $appt): ?>
            <div class="card">
                <div class="card-header">
                    <div class="patient-name"><?= htmlspecialchars($appt['patient_name']) ?></div>
                    <div class="status">Critical</div>
                </div>
                <div class="details">
                    <div><strong>Date:</strong> <?= htmlspecialchars($appt['appt_date']) ?> | <strong>Time:</strong> <?= htmlspecialchars($appt['appt_time']) ?></div>
                    <div><strong>Type:</strong> <?= htmlspecialchars($appt['appt_type']) ?></div>
                    <?php if($appt['notes']): ?>
                        <div><strong>Notes:</strong> <?= htmlspecialchars($appt['notes']) ?></div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="card">
            <div class="details">No critical alerts at the moment.</div>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
